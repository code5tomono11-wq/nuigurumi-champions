const http = require("http");

const server = http.createServer((req,res)=>{
res.writeHead(200,{"Content-Type":"text/plain; charset=utf-8"});
res.end("ぬいぐるみチャンピオンズ サーバー起動中");
});

server.listen(3000,()=>{
console.log("起動 http://localhost:3000");
});
